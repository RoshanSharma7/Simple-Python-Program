first = float(input('Enter value: '))
second = float(input('Enter value: '))
thred = float(input('Enter value: '))

if (first > second and first > thred):
  print('first no is greter then other no')

elif (second > first and second > thred):
  print('second no is greter then other no')

else:
  print('thred no is greter then other no')