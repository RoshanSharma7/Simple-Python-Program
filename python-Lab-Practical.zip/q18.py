user_list = []
no = int(input('How many strings you want to concatenate: '))

for i in range(no):
  element = input('Enter the string: ')
  user_list.append(element)

result = ''.join(user_list)
print('The concatenated string is:', result)
print('The repesentation of the concateneted string:', result * 2)
