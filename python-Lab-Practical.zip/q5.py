username = input('Enter the user name: ')
password = input('Enter the password: ')

if(username == 'roshan' and password == 'roshan@123'):
  print("Welcome the python programming comunity")
  print('If condistion is work sucessfully!')

else:
  print('Sorry username and password is wrong, retry!')
  print('Else part is sucessfully work')