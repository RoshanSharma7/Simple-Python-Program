first = 7
second = 7.0
thred = 'Roshan'
forth = bool(1)

print("The given first data type is: ", type(first))
print("The given second data type is: ", type(second))
print('The given thred data type is: ', type(thred))
print("The given forth data type is: ", type(forth))