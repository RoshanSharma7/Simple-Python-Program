# function with argumant & without return value
def hello(user):
  print("Hello,", user)

user = input("Enter your name: ")
hello(user)