user_list = []
number = int(input('Enter the how many elements you want in your list: '))
for i in range(number):
  element = input('Enter the element: ')
  user_list.append(element)

print('List elements:')
for i in user_list:
  print('List elements:', i)