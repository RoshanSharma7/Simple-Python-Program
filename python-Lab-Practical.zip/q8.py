user =  int(input('Enter the number: '))
order = len(str(user))   # count lenght of given number
sum = 0
copy_n = user            # copy of given number

while (user > 0):
  digit = user % 10      # get last digit of given number
  sum += digit ** order  # power of the last digit
  user = user // 10      # remove last digit

if (sum == copy_n):              # compaision of sun & given number
  print(copy_n, "is armstrong")
else:
  print(copy_n, "is not armstrong")