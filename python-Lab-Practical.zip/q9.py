user_input = int(input("Enter the number: "))
fact = 1
copy_user_input = user_input

while(user_input > 0):
  fact = fact * user_input
  user_input = user_input - 1

print('Factorial of', copy_user_input, "is", fact) 