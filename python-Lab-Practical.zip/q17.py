str = input('Enter the string: ')
count = len(str)
i = 0

print('Character of enter string')
for i in str:
  print(i)