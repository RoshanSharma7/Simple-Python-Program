value = input('Enter the value: ')

reversed_value = value[::-1]
print('The reversed value: ', reversed_value)
