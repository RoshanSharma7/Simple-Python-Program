first = float(input('Enter the first no: '))
second = float(input("Enter the second no: "))
sym = input('Enter the symbol: ')

if sym == '+':
  print(first + second)

elif sym == '-':
  print(first - second)

elif sym == '*':
  print(first * second)

elif sym == '/':
  print(first / second)

elif sym == '%':
  print(first % second)

elif sym == '++':
  print(first ++ second)

elif sym == '--':
  print(first -- second)

elif sym == '**':
  print(first ** second)

elif sym == '//':
  print(first // second)

else:
  print('invelid symbol entered!')
  