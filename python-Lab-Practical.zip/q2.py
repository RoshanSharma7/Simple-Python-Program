real1 = float(input('Enter the first real no: '))
imag1 = float(input('Enter tbe first imag no: '))

real2 = float(input('Enter the second real no: '))
imag2 = float(input('Enter the second imag no: '))

first = complex(real1, imag1)
second = complex(real2, imag2)

print('The sum of the two complex no is: ',first + second)


