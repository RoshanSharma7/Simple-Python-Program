# function without argumant & return value
def hello():
  print('Hello, Python!')

hello()