number = int(input("Enter the no: "))

if(number % 2 == 0):
  print('Given number is even')

else:
  print('Given number is odd')