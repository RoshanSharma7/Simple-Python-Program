# Function without argumant & with return type
def add():
  first = float(input('Enter the first no: '))
  second = float(input('Enter the second no: '))
  return first + second

result = add()
print('The sum of two number is:', result)
