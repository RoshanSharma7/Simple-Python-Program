number = float(input('Enter the number: '))

if(number > 0):
  print('The number is positive')

elif (number == 0):
  print('The number is qual to 0')

else:
  print('The number is negetive')