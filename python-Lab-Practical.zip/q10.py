user_input = int(input('Enter the number: '))
sum = 0

while (user_input > 0):
  digit = user_input % 10
  sum = sum + digit
  user_input = user_input // 10

print('Sum of the given number digits: ', sum)