my_list = []

no = int(input('How many element are enter: '))

for i in range(no):
  my_list.append('Enter the values: ')

app = int(input('Enter the appand value: '))
print(my_list.append(app))

ind = int(input('Enter the index no: '))
ins = int(input('Enter the insrt data: '))
print(my_list.insert(ind, ins))

print(my_list.sort())