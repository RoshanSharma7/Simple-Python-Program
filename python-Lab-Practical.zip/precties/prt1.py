# set
empty_set = {0}
single_set = {True, }
mixed_set = {7, 'Roshan', False, 9.7}

# print(type(empty_set))
# print(type(single_set))
# print(type(mixed_set))

furit1 = {'apple', 'banana'}
furit2 = { 'mango', 'grapes', 'orange'}
person = {'roshan', 'rohit', 'mango'}

print(furit1, person)
#add the item, set, other type of arrays
furit1.add('kivi')      # add one item in the set
print(furit1)

furit1.update(furit2)    # add the 2 set in tugether
print('the comination of two set: ', furit1)

furit2.update(person)
print('the combination of two other type of arrays: ', furit2)

#removing the item, set
furit2.remove('grapes')      #using remove function
print('Remove item is grapes now the set is: ', furit2)

furit2.discard('syam')      # using discard function
print('After removeing the syam, the set is: ', furit2)

"""
using pop method, but in pop method 
there is not a fixed, which item is removed 
"""   
furit2.pop()              
print('Removing somtimg in this set: ', furit2)

del furit2

#loop in set
for i in furit1:
  print(i)

#union use for the combine and allow the duplicatsy
newset = person.union(furit1)
print('union of two set: ', newset)

"""
intersection use for keeping only duplicatsy.
only intersection, we need to new veriable to store intersection value,
intersection_update() is don't need any veriable to store intersecton value
"""
new_set = person.intersection(furit1)         #intersection mathod
print('intersection of two set: ', new_set)

furit1.intersection_update(person)            #intersection_update() mathod
print('intersection of two set: ', furit1)