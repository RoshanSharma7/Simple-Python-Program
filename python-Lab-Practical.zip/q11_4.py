# function with the argumant & return type
def login(username, password):
  if (username == 'roshan' and password == 'roshan@123'):
    print('Login sucessfully!')
    return True

  else:
    print('Invalid username or password!')
    return False

user = input('Username: ')
pas = input('Password: ')
login(user, pas)

