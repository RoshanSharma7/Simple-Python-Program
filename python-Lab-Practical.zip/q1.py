first = float(input('Enter value: '))
second = float(input('Enter value: '))

print('The sum of two no is:', first+second)