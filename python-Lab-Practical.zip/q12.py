first = float(input('Enter value: '))
second = float(input('Enter value: '))

print('Before swaping:_-')
print('First value is:', first)
print('Second value is:', second)

thred = first
first = second
second = thred

print('After swaping:-')
print('Now the first value is:',first)
print('Now the second value is:', second)